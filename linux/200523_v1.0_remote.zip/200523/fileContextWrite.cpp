#include <bits/stdc++.h>
#include <unistd.h>

using namespace std;

int main()
{
	std::ofstream ofs("file");
	for(int i = 0; i < 100; i++)
	{
		ofs<<"***This is number "<<i<<" lines in this file***"<<std::endl;
	}
	ofs.close();
	return 0;
}
