make
./main_server 127.0.0.1 8000
